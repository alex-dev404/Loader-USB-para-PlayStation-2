bmp2icon v0.2 - by Sjeep
========================

bmp2icon is a tool which will take a 128x128 24-bit bitmap, and convert it into
a ps2 memory card icon file. The resulting icon is a selectable shape with your
bitmap "wrapped" around it. In the current implimentation, the following icon
shapes are available: 3D cube, 3D rectangle, flat square.

Currently only the win32 version of this tool is available, as the command-
line version is out of sync. The next release will include a win32 binary
and C source for the command line version.

Please direct any feedback to: sjeep@gamebase.ca

- Sjeep
